import {Component} from '@angular/core';
import { UserService } from '../app/services/user.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  constructor(private userService: UserService) {

  }

  ngOnInit() {
  	this.preguntarLogueado()  	//SETEA loged EN TRUE SI EL USUARIO ESTA LOGUEADO
  	this.preguntarTipo()		//SETEA tipoAdmin EN TRUE SI EL USUARIO ES DE TIPO ADMIN
  }

  loged = false;
  tipoAdmin = false;
  nombre = "";

  desloguearUsuario()
  {
  	this.userService.usserLogged = this.userService.getUserLoggedIn() 
	this.userService.setUserLoggedOut(this.userService.usserLogged);
  }

  preguntarLogueado(){
    this.userService.usserLogged = this.userService.getUserLoggedIn()
  	if (this.userService.getUserLoggedIn().logueado == 2){
  		this.loged = true
  	}
  }

  preguntarTipo(){
    this.userService.usserLogged = this.userService.getUserLoggedIn()
  	if (this.userService.getUserLoggedIn().tipo == 2){
  		this.tipoAdmin = true
  		this.nombre = "Hola " + this.preguntarNombre() + "! (Usuario Admin)"	//SETEO STRING DE BIENVENIDA PARA ADMIN
  	} 
  	else
  	{
		this.nombre = "Hola " + this.preguntarNombre() + "! (Usuario Standard)"	//SETEO STRING DE BIENVENIDA PARA STANDARD
  	}
  }

  preguntarNombre(){
    this.userService.usserLogged = this.userService.getUserLoggedIn()
  	return this.userService.getUserLoggedIn().username
  }

}
