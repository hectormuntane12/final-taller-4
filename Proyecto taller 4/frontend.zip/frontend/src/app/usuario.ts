export class Usuario {
    id: number;
    tipo: number;
    username: string;
    email: string;
    password: string;
    logueado: number;
    primerInicio: boolean;
}
