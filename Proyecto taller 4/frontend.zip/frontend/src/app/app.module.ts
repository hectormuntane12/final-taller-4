import {BrowserModule} 	from '@angular/platform-browser';
import {NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {AppRoutingModule} from './app-routing.module';
import {HttpClientModule} from '@angular/common/http';

import {AppComponent} from './app.component';
import {HomeComponent} from './home/home.component';
import {RegistroComponent} from './registro/registro.component';
import {LoginComponent} from './login/login.component';
import {AdminComponent} from './admin/admin.component';
import {StandardComponent} from './standard/standard.component';

import {RegistroService} from './services/registro.service';
import {LoginService} from './services/login.service';
import {AdminService} from './services/admin.service';
import {UserService} from './services/user.service';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    RegistroComponent,
    LoginComponent,
    AdminComponent,
    StandardComponent

  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [RegistroService, LoginService, AdminService, UserService],
  bootstrap: [AppComponent]
})
export class AppModule {
}
