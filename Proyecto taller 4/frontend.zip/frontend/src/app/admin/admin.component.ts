import { Component, OnInit, Injectable } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminService } from '../services/admin.service';
import { Usuario } from '../usuario';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})

@Injectable()
export class AdminComponent implements OnInit {
	
	users$;
	usuario: Usuario = new Usuario();

	firstLoad = false;

	constructor(
		private adminService:AdminService,
		private route:ActivatedRoute, 
		private router:Router,
		private userService: UserService) {
	};

	async ngOnInit() {
		this.users$ = await this.adminService.getAllUsers();

		//SI ES USUARIO NO ESTA LOGUEADO O NO ES DE TIPO ADMIN NO LO DEJA ENTRAR A LA PAGINA
	  	if (this.userService.getUserLoggedIn().logueado == 1  || this.userService.getUserLoggedIn().tipo == 1){
	  		this.router.navigate(['/home']);
	  	}

	  	//REFRESHEO DE PAGINA PARA ACTUALIZA NAVBAR
	  	if (this.userService.getUserLoggedIn().primerInicio == true){
	  		this.userService.setUserPrimerInicio(this.userService.getUserLoggedIn())
	  		window.location.reload(); 
	  	}
	}

	delete(){
		var id = this.usuario.id;
		this.adminService.deleteUser(id).subscribe(data => {
  			window.location.reload();
  		});
	}

}
