import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-standard',
  templateUrl: './standard.component.html',
  styleUrls: ['./standard.component.css']
})
export class StandardComponent implements OnInit {

  constructor(
  	private router:Router,
  	private userService: UserService){ 
  }

  ngOnInit(){
      //SI ES USUARIO NO ESTA LOGUEADO NO LO DEJA ENTRAR A LA PAGINA
  		if (this.userService.getUserLoggedIn().logueado == 1){
	  		this.router.navigate(['/home']);
	  	}

      //REFRESHEO DE PAGINA PARA ACTUALIZA NAVBAR
      if (this.userService.getUserLoggedIn().primerInicio == true){
        this.userService.setUserPrimerInicio(this.userService.getUserLoggedIn())
        window.location.reload(); 
      }
  }

}
