import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Usuario } from '../usuario';
import { UserService } from '../services/user.service';
import { RegistroService } from '../services/registro.service';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent implements OnInit {

  usuario: Usuario = new Usuario();
  submitted = false;
  confirm: String;
  errorPassword: String;
  fail = false; 

  constructor(
    private registroService: RegistroService,
    private route: ActivatedRoute,
    private router: Router,
    private userService: UserService
  ) { }

  ngOnInit() {
      if (this.userService.getUserLoggedIn().logueado == 2){
        this.router.navigate(['/home']);
      }
  }

  newUsuario(): void{
  	this.submitted = false;
  	this.usuario = new Usuario();
  	this.router.navigate(['/home']);
  }

  onSubmit() {
    this.save();
  }

  save(){
    this.errorPassword="";
    if (this.usuario.password == this.confirm){
    	this.registroService.postRegistro(this.usuario).subscribe((data) => {
        console.debug(data);
        if (data == null){
          this.fail = true;
        }else if(data == true){
          this.fail = false;
          this.usuario = new Usuario();
          this.submitted = true;
        }
      });
    }
    else {
      this.errorPassword = "Las contraseñas no coinciden!";
    }

  }
 
}
