import {NgModule} from '@angular/core';
import {Routes, RouterModule} from '@angular/router';

import {HomeComponent} from './home/home.component';
import {RegistroComponent} from './registro/registro.component';
import {LoginComponent} from './login/login.component';
import {AdminComponent} from './admin/admin.component';
import {StandardComponent} from './standard/standard.component';


const routes: Routes = [
	{ path: 'registro',	component: RegistroComponent },
	{ path: 'login', component: LoginComponent,	pathMatch: 'full' },
	{ path: 'admin', component: AdminComponent },
	{ path: 'standard',	component: StandardComponent },
	{ path: 'home', component: HomeComponent },
	{ path: '**', redirectTo: '/home' }
	];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule {
}
