import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../services/login.service';
import { UserService } from '../services/user.service';
import { Usuario } from '../usuario';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

	fail = false;

	constructor(private loginService: LoginService,  
				private router: Router,
				private userService: UserService){
	 }
	
	usuario: Usuario = new Usuario();

	ngOnInit() {
		if (this.userService.getUserLoggedIn().logueado == 2){
	  		this.router.navigate(['/home']);
	  	}
	}

	login(){
		this.loginService.login(this.usuario).subscribe((data) => {
			console.debug(data);
			if (data == 2){
				this.fail = false
				let u: Usuario = this.usuario;  
				this.userService.setUserLoggedInAdmin(u);
				console.debug("Redireccionando admin....");
				this.router.navigate(['/admin']);
			}
			else if (data == 1){
				this.fail = true
				let u: Usuario = this.usuario; 
				this.userService.setUserLoggedInStandard(u);			
				console.debug("Redireccionando standard user....");
				this.router.navigate(['/standard']);
			}
			else if (data == null){
				this.fail = true
			}
		});
	}
	
}
