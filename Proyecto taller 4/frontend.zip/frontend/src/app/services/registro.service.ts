import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Usuario } from '../usuario';

@Injectable()
export class RegistroService {
	
	private baseUrl = 'http://localhost:8080/api';
	
	constructor(private http: HttpClient){

	}

	postRegistro(usuario: Usuario): Observable<Object> {
    	return this.http.post(`${this.baseUrl}/registro`, usuario);
  	}
 
}
