import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';


@Injectable()
export class AdminService {

  private baseUrl = 'http://localhost:8080/api';

  constructor(private http: HttpClient) { }

  getAllUsers(){
  	return this.http.get(`${this.baseUrl}/usuario`);
  }

  deleteUser(id : number){
  	//this.http.delete(`${this.baseUrl}/borrar/${id}`).subscribe(() => console.debug("user deleted"));
  	return this.http.delete(`${this.baseUrl}/borrar/${id}`, {responseType: 'text'});
  }

}
