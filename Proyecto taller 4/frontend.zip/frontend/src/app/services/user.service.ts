import { Injectable } from '@angular/core';
import { Usuario } from '../usuario';

@Injectable()
export class UserService {

  private isUserLoggedIn;
  public usserLogged:Usuario;

  constructor() { 
  	this.isUserLoggedIn = false;
  }

  setUserPrimerInicio(user:Usuario)
  {
    this.usserLogged = user;
    this.usserLogged.primerInicio = false;
    localStorage.setItem('currentUser', JSON.stringify(user));
  }

  //LOGUEAR USUARIO ADMIN
  setUserLoggedInAdmin(user:Usuario) 
  {
    this.isUserLoggedIn = true;
    this.usserLogged = user;
    this.usserLogged.logueado = 2;
    this.usserLogged.tipo = 2; //Tipo admin user
    this.usserLogged.primerInicio = true;
    localStorage.setItem('currentUser', JSON.stringify(user));
  
  }

  //LOGUEAR USUARIO STANDARD
  setUserLoggedInStandard(user:Usuario) 
  {
    this.isUserLoggedIn = true;
    this.usserLogged = user;
    this.usserLogged.logueado = 2;
    this.usserLogged.tipo = 1;  //Tipo standard user
    this.usserLogged.primerInicio = true;
    localStorage.setItem('currentUser', JSON.stringify(user)); 
  }

  //OBTENER USUARIO GUARDADO EN MEMORIA

  getUserLoggedIn() 
  {
  	return JSON.parse(localStorage.getItem('currentUser'));
  }

  //DESLOGUEAR USUARIO
  setUserLoggedOut(user:Usuario)
  {
  	this.isUserLoggedIn = false;
    this.usserLogged = user;
    this.usserLogged.logueado = 1;
    localStorage.setItem('currentUser', JSON.stringify(user));
  }

}
