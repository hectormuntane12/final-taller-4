import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Usuario } from '../usuario';

@Injectable()
export class LoginService {
  constructor(private http: HttpClient) { }

  private baseUrl = 'http://localhost:8080/api';
  
  login(usuario: Usuario) {
  	return this.http.post(`${this.baseUrl}/login`, usuario);
  };

}
