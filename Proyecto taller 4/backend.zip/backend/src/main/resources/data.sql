INSERT INTO app_role (id, role_name, description) VALUES (1, 'STANDARD_USER', 'Usuario estandar');
INSERT INTO app_role (id, role_name, description) VALUES (2, 'ADMIN_USER', 'Usuario Admin');

INSERT INTO app_user (username,email,password) VALUES ('luciano','diamand@yahoo.com','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4');
INSERT INTO app_user (username,email,password) VALUES ('hector','muntane@gmail.com','03ac674216f3e15c761ee1a5e255f067953623c8b388b4459e13f978d7c846f4');

INSERT INTO user_role(user_id, role_id) VALUES(1,1);
INSERT INTO user_role(user_id, role_id) VALUES(1,2);
INSERT INTO user_role(user_id, role_id) VALUES(2,1);

