package ips.edu.com.ar.proyectotaller4;

import java.util.List;

public interface UsuarioService {
	
	//POST
	public boolean crearUsuario(String nombre, String email, String password);
	public int loginUser(String nombre, String password);
	
	//DELETE
	public void deleteUsuarioById(Long id);
	
	//GET
	public Usuario getUsuarioByName(String username);
	public List<Usuario> getUsuarios();
	public Usuario getUsuarioById(Long id);
}
