package ips.edu.com.ar.proyectotaller4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;

@RestController
@RequestMapping("/api")
public class UsuarioRestController {
	
	@Autowired
	private UsuarioService u;
	
	@CrossOrigin
	@PostMapping("/registro")
	 public boolean postRegistro(@RequestBody Usuario user) {
		return u.crearUsuario(user.getUsername(), user.getEmail(), user.getPassword());
	 }
	 
	@CrossOrigin
	@PostMapping("/login")
	public int getLogin(@RequestBody Usuario user){
		return (u.loginUser(user.getUsername(), user.getPassword()));	
	}
	
	@CrossOrigin
	@DeleteMapping("/borrar/{id}")
	public void borrarUsuario(@PathVariable("id")Long id) {
		u.deleteUsuarioById(id);
	}
	
	@CrossOrigin
	@GetMapping("/usuario")
	public List<Usuario> getUsuarios() {
		return u.getUsuarios();
	}

	@CrossOrigin
	@GetMapping("/usuario/{id}")
	public Usuario getUsuario(@PathVariable("id")Long id) {
		return u.getUsuarioById(id);
	}
	
}