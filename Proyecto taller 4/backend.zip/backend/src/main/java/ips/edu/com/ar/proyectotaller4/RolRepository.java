package ips.edu.com.ar.proyectotaller4;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.rest.core.annotation.RepositoryRestResource;

@RepositoryRestResource()
public interface RolRepository extends JpaRepository<Rol,Long> {
	
	
}