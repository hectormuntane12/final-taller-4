package ips.edu.com.ar.proyectotaller4;

import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UsuarioServiceImpl implements UsuarioService {
	
	@Autowired
	private UsuarioRepository repoU;
	@Autowired
	private RolRepository repoR;
	
	private Usuario u;
	private List<Rol> r;
	
	public boolean crearUsuario(String username, String email, String password){
		
		if(username == null | email == null | password == null) {
			return false;
		}
		
		r = new ArrayList<Rol>();
		r.add(repoR.findById((long) 1).get());

		u = new Usuario();
		u.setUsername(username);
		u.setEmail(email);
		u.setPassword(getSha256(password));
		u.setRoles(r);

		repoU.save(u);	
		
		return repoU.existsById(u.getId());
	}

	public int loginUser(String username, String password){
		
		u = getUsuarioByName(username);
		
		if(getSha256(password).equals(u.getPassword())){
			
			if(u.getRoles().contains(repoR.findById((long) 2).get())) {
				
				return 2;
			}
			
			return 1;
		}
		
		return 0;
	}
	
	public Usuario getUsuarioByName(String username) throws IndexOutOfBoundsException, NullPointerException{
		
		try{
			u = repoU.findByUsername(username).get(0);
		}catch(IndexOutOfBoundsException e){
			e.printStackTrace();
		}catch(NullPointerException e){
			e.printStackTrace();
		}
		
		return u;
		
	}
	
	public List<Usuario> getUsuarios() {	
	
		return repoU.findAll();
		
	}

	
	public Usuario getUsuarioById(Long id) {
		
		u = repoU.findById(id).get();
	
		return u;
		
	}
	
	public void deleteUsuarioById(Long id) {
		
		repoU.deleteById(id);			
		
	}
	
	//FUNCIONES DE HASHEO
    private static String getSha256(String valor) {
    	try{
    		MessageDigest md = MessageDigest.getInstance("SHA-256");
    		md.update(valor.getBytes());
    		return bytesToHex(md.digest());
		} catch(Exception ex){
			throw new RuntimeException(ex);
		}
	}
	 
    private static String bytesToHex(byte[] bytes) {
    	StringBuffer resultado = new StringBuffer();
    	for (byte b : bytes) resultado.append(Integer.toString((b & 0xff) + 0x100, 16).substring(1));
    	return resultado.toString();
    }	
}