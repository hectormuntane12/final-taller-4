package ips.edu.com.ar.proyectotaller4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyectotaller4Application {

	public static void main(String[] args) {
		SpringApplication.run(Proyectotaller4Application.class, args);
	}
}
